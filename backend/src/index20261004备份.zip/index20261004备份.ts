import { Hono } from "hono";
import { serve } from "@hono/node-server";
import { cors } from "hono/cors";
import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";

const DATA_FILE = path.join(process.cwd(), "data.json");

// 简单 JSON 文件存储（免数据库，Windows 零问题）
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
    }
  } catch (e) {
    console.warn("读取数据文件失败，使用空数据");
  }
  return { users: {}, events: [] };
}

function saveData(data: any) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
}

let db = loadData();

const app = new Hono();

// 跨域
app.use(
  "*",
  cors({
    origin: ["http://localhost:8000", "http://127.0.0.1:8000", "http://localhost:3000"],
    allowMethods: ["GET", "POST", "OPTIONS"],
    allowHeaders: ["Content-Type", "Authorization"],
  })
);

const AUTH_TOKEN = "test-token-123";

app.use("/api/*", async (c, next) => {
  const auth = c.req.header("Authorization");
  if (auth !== `Bearer ${AUTH_TOKEN}`) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  await next();
});

// 健康检查
app.get("/", (c) => c.json({ status: "ok", message: "社畜解放卡后端运行中（纯JS版）" }));

// 1. 提交情绪记录
app.post("/api/v1/mood/events", async (c) => {
  try {
    const body = await c.req.json();
    const { user_id, category_code, score = 1, note } = body;

    if (!user_id || !category_code) {
      return c.json({ error: "缺少必要字段 user_id 或 category_code" }, 400);
    }

    // 确保用户存在
    if (!db.users[user_id]) {
      db.users[user_id] = {
        id: user_id,
        nickname: "打工人",
        createdAt: new Date().toISOString(),
      };
    }

    const eventId = "evt_" + randomUUID().slice(0, 8);
    const event = {
      id: eventId,
      userId: user_id,
      categoryCode: category_code,
      score: Number(score) || 1,
      note: note || null,
      recordedAt: new Date().toISOString(),
    };

    db.events.push(event);
    saveData(db);

    // 计算总点数
    const userEvents = db.events.filter((e: any) => e.userId === user_id);
    const totalPoints = userEvents.reduce((sum: number, e: any) => sum + (e.score || 1), 0);
    const disgustIndex = Math.min(100, Number(((totalPoints / 100) * 80 + 10).toFixed(1)));

    return c.json(
      {
        event_id: eventId,
        total_points: totalPoints,
        disgust_index: disgustIndex,
      },
      201
    );
  } catch (err) {
    console.error(err);
    return c.json({ error: "服务器内部错误" }, 500);
  }
});

// 2. 获取历史趋势与统计
app.get("/api/v1/mood/stats", async (c) => {
  try {
    const userId = c.req.query("user_id");
    const days = Number(c.req.query("days") || 14);

    if (!userId) {
      return c.json({ error: "缺少 user_id" }, 400);
    }

    const since = new Date();
    since.setDate(since.getDate() - days);

    const events = db.events.filter((e: any) => {
      return e.userId === userId && new Date(e.recordedAt) >= since;
    });

    const categoryBreakdown: Record<string, number> = {};
    const trendMap: Record<string, number> = {};

    events.forEach((e: any) => {
      categoryBreakdown[e.categoryCode] = (categoryBreakdown[e.categoryCode] || 0) + (e.score || 1);
      const dateStr = e.recordedAt.slice(0, 10);
      trendMap[dateStr] = (trendMap[dateStr] || 0) + (e.score || 1);
    });

    const trend = Object.entries(trendMap)
      .map(([date, points]) => ({ date, points }))
      .sort((a, b) => a.date.localeCompare(b.date));

    const totalPoints = events.reduce((sum: number, e: any) => sum + (e.score || 1), 0);

    return c.json({
      total_points: totalPoints,
      category_breakdown: categoryBreakdown,
      trend,
    });
  } catch (err) {
    console.error(err);
    return c.json({ error: "服务器内部错误" }, 500);
  }
});

const port = 3001;
console.log(`🚀 社畜解放卡后端已启动：http://localhost:${port}`);
serve({ fetch: app.fetch, port });